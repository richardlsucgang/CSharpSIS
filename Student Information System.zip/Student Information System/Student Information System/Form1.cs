﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Student_Information_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dgvStudents.ColumnCount = 8;
            dgvStudents.Columns[0].Name = "StudentNumber";
            dgvStudents.Columns[1].Name = "FirstName";
            dgvStudents.Columns[2].Name = "LastName";
            dgvStudents.Columns[3].Name = "Age";
            dgvStudents.Columns[4].Name = "Gender";
            dgvStudents.Columns[5].Name = "Birthday";
            dgvStudents.Columns[6].Name = "Year Level";
            dgvStudents.Columns[7].Name = "Skills";
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           DataGridViewImageColumn dgvImage = new DataGridViewImageColumn();
            dgvImage.HeaderText = "Image";
            dgvImage.ImageLayout = DataGridViewImageCellLayout.Stretch;
            dgvStudents.Columns.Add(dgvImage);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string gender = "", skills = "";
            if (rbMale.Checked)
            {
                gender = "Male";
            }else if(rbFemale.Checked){
                gender = "Female";
            }

            if (chckCpp.Checked)
            {
                skills += "C++ ";
            }
            if (chckCs.Checked)
            {
                skills += "C# ";
            }
            if (chckJava.Checked)
            { 
                skills += "JAVA ";
            }
            if (chckPHP.Checked)
            {
                skills += "PHP ";
            }
            if (chckVB.Checked)
            {
                skills += "VB.NET ";
            }
            if (chckPhyton.Checked)
            {
                skills += "PHYTON";
            }

            MemoryStream memoryStream = new MemoryStream();
            picImage.Image.Save(memoryStream, picImage.Image.RawFormat);
            byte[] img = memoryStream.ToArray();


            dgvStudents.Rows.Add(
                txtStudentNumber.Text,
                txtFname.Text,
                txtLname.Text,
                numAge.Value,
                gender,
                dtbBirthday.Value,
                cboYearlevel.SelectedItem,
                skills,
                img);
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Choose image(*.jpg;*.png;*.gif) | *.jpg;*.png;*.gif";

            if(dlg.ShowDialog() == DialogResult.OK)
            {
                picImage.Image = Image.FromFile(dlg.FileName);
            }
        }
    }
}
